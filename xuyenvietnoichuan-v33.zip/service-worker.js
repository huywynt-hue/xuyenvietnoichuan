// Lưu sẵn game trong máy để mở nhanh. Khi sửa game, tăng số phiên bản bên dưới.
const CACHE = 'phatam-v33';
const FILES = ['./', './index.html', './manifest.json', './icon-192.png', './icon-512.png', './apple-touch-icon.png', './firebase-config.js', './chinh-sach-rieng-tu.html', './nguon-tham-khao.html'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(FILES)));
  self.skipWaiting();
});

self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))));
  self.clients.claim();
});

self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  // Không can thiệp trang đăng nhập Firebase và các trang của Google
  const u = new URL(e.request.url);
  if (u.origin !== location.origin || u.pathname.startsWith('/__/')) return;
  // Ưu tiên bản mới trên mạng; mất mạng thì dùng bản đã lưu.
  // Bổ sung v22: mạng chập chờn (quá 4 giây chưa tải xong) thì mở ngay bản đã lưu, bản mới vẫn tải ngầm.
  const net = fetch(e.request).then(res => {
    if (res && res.ok) { const copy = res.clone(); caches.open(CACHE).then(c => c.put(e.request, copy)).catch(() => {}); }
    return res;
  });
  const fallback = () => caches.match(e.request).then(r => r || caches.match('./index.html'));
  e.respondWith(new Promise(resolve => {
    let done = false;
    const t = setTimeout(() => { fallback().then(r => { if (r && !done) { done = true; resolve(r); } }); }, 4000);
    net.then(res => { if (!done) { done = true; clearTimeout(t); resolve(res); } })
       .catch(() => fallback().then(r => { if (!done) { done = true; clearTimeout(t); resolve(r || Response.error()); } }));
  }));
});
